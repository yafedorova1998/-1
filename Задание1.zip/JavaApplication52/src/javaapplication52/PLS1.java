package javaapplication52;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.event.*; 
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import javax.swing.*; 
import static javax.swing.SwingUtilities.paintComponent;

public class PLS1 {
    public static void main(String[] args) {
      JFrame frame = new JFrame("Приложение");
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
frame.setSize(900,800);
frame.setVisible(true);
JPanel p1 = new JPanel(new BorderLayout()); 
JButton btn1 = new JButton("Начать работу"); 
btn1.setVisible(true); 
btn1.setLocation(350, 330); 
btn1.setSize(200, 100); 
JButton btn2 = new JButton("Подробнее");
btn2.addActionListener(new ActionListener() { 
public void actionPerformed(ActionEvent e) { 
new Win2("Подробнее", 300, 400); 
} 
});
btn2.setVisible(true); 
btn2.setLocation(680, 0); 
btn2.setSize(200, 70); 
frame.getContentPane().add(btn1); 
frame.getContentPane().add(new JLabel()); 
frame.getContentPane().add(btn2); 
frame.getContentPane().add(new JLabel()); 

class Canvas extends JComponent{
  public void paintComponent(Graphics g){
	super.paintComponents(g);
        g.setColor(Color.YELLOW);
        g.fillOval(100,200,70,70);
        g.fillOval(200,600,70,70);
        g.fillOval(500,400,70,70);
        g.fillOval(700,50,70,70);
        g.setColor(Color.BLUE);
        g.fillOval(50,70,60,60);
        g.fillOval(300,150,60,60);
        g.fillOval(450,550,60,60);
        g.fillOval(600,150,60,60);
        g.setColor(Color.MAGENTA);
        g.fillOval(590,300,80,80);
        g.fillOval(100,450,80,80);
        g.fillOval(700,470,80,80);
        g.fillOval(350,50,80,80);
        g.setColor(Color.BLACK);
        Font font = new Font("TimesRoman", Font.BOLD|Font.ITALIC, 30);
         g.setFont(font); 
          g.drawString("Добро пожаловать!", 300, 250);
  }
}
Canvas canv=new Canvas();
        frame.add(canv);		
        frame.setVisible(true);	
    }
}
