package javaapplication52;

import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.io.BufferedReader; 
import java.io.FileReader; 
import java.io.IOException; 
import java.io.LineNumberReader; 
import javax.swing.JFrame; 
import javax.swing.JTextArea; 

class Win2 implements ActionListener { 
FileReaderClass File = new FileReaderClass(); 
JTextArea textArea; 
public Win2(String text, int x, int y) { 
JFrame aaa = new JFrame("Подробнее"); 
aaa.setBounds(250, 300, 550, 400); 
aaa.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
aaa.setLayout(null); 
textArea = new JTextArea(); 
textArea.setBounds(80, 100, 330, 250); 
textArea.setEditable(false); 
textArea.append(File.read()); 
aaa.add(textArea); 
aaa.setVisible(true); 
} 
public void actionPerformed(ActionEvent ae) { 
} 
} 
class FileReaderClass { 
public String read() { 
StringBuilder text = new StringBuilder(); 
try { 
String s; 
FileReader fr = new FileReader("C:/CD/xanadu.txt"); 
BufferedReader br = new BufferedReader(fr); 
LineNumberReader lr = new LineNumberReader(br); 
while ((s = lr.readLine()) != null) { 
text.append(s); 
text.append("\n"); 
} 
} catch (IOException e) { 
System.out.println(e.getMessage()); 
} 
return text.toString(); 
} 

}  